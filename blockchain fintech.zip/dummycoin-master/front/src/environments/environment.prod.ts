export const environment = {
  production: true,
  defaultApiHost: 'http://dummycoin.alexbyk.com/grpcproxy',
  docsBase: 'http://dummycoin.alexbyk.com/docs',
};
